/*
* Author: Tai Eric Ho
* Target: enhancement2.html
* Purpose: assignment 2
* Credits: Eric Ho
*/


//https://www.w3schools.com/jsref/met_win_setinterval.asp set interval for 1secs
function timer(){
    var count = document.getElementById("timer").textContent;
    var countdown = setInterval(function(){
    count--;
    document.getElementById("timer").textContent = count;
    if(count <= 0){
     alert("You have ran out of time"); //run out of time.
	/* CODE BELOW IS WHAT WAS ADDITIONALLY USED IN QUIZ.JS
	if (localStorage.getItem("firstName") !== null){
	   var names = [localStorage.getItem("firstName"), localStorage.getItem("surname"),localStorage.getItem("studID"), 2]
		} 
     else {
	   var names = ["failed", "the test", 0, 2]
		}
		 saveResult(names);
		 window.location.href = "result.html"; // after failing with time run out it will direct to results
	}*/
	 clearInterval(countdown);//finish counting
     }},1000);
}
	
//enhancements using javascript to change the first letter of the names to always be capital in the results.
//https://www.w3schools.com/jsref/jsref_toUpperCase.asp Where I learn upper
function change(){
   	var firstname = document.getElementById("firstName").value;
	var surname = document.getElementById("surname").value;
	firstname = firstname.charAt(0).toUpperCase() + firstname.slice(1);//first letter plus (value less first letter)
	surname = surname.charAt(0).toUpperCase() + surname.slice(1);
	document.getElementById("firstName").value = firstname;
	document.getElementById("surname").value = surname;
}	

	

window.onload = function (){
	timer();
	document.getElementById("test").onclick = change;
}
	


 