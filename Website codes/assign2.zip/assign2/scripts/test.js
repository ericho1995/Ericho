/*
* Author: Tai Eric Ho
* Target: enhancement2.html
* Purpose: assignment 2
* Credits: Eric Ho
*/


//https://www.w3schools.com/jsref/jsref_parseint.asp how I learn about parseInt
//https://www.w3schools.com/jsref/met_win_setinterval.asp set interval for 1secs


	

window.onload = function() {
	timer();
}


