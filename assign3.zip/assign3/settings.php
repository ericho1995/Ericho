
<?php
  
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s103279560";
	$pwd = "newpwd";
	$sql_db = "s103279560_db";
?>

