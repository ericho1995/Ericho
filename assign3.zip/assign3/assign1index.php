<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" >
  <meta name="description" content="Assignment 1"/>
  <meta name="keywords" content="Assignment,Week 1-3,single,page,application"/>
  <meta name="author" content="Tai Eric Ho"/>
  <title>Single page application</title>
  <link href= "styles/style.css" rel="stylesheet"/>
  <link href= "styles/index.css" rel="stylesheet"/>
  <link href="styles/enhancement.css" rel="stylesheet"/>
  
 <body>
<?php
include_once "indexheader.inc";
include_once "nav.inc";
?>   
     <br>
     <h2>Assignment 1. Single Page Applications</h2>
	 <section>
     <h3>Please select your destination.</h3>
	 <span>You can hover to get a preview of the pages.</span>
	 <a href="https://mercury.swin.edu.au/cos10011/s103279560/assign1/topic.html"><h3>Topic page</h3></a>
	 <div class="preview">
	 <iframe src="https://mercury.swin.edu.au/cos10011/s103279560/assign1/topic.html" width="1000" height="500"></iframe></div>	 
	 <a href="https://mercury.swin.edu.au/cos10011/s103279560/assign1/quiz.html"><h3>Quiz page</h3></a>
	 <div class="preview">
	 <iframe src="https://mercury.swin.edu.au/cos10011/s103279560/assign1/quiz.html" width="1000" height="500"></iframe></div>
	 <a href="https://mercury.swin.edu.au/cos10011/s103279560/assign1/enhancement.html"><h3>Enhancement</h3></a>
	 <div class="preview">
	 <iframe src="https://mercury.swin.edu.au/cos10011/s103279560/assign1/enhancement.html" width="1000" height="500"></iframe></div>
     </section>
	 
	 <!-- iframe used here as an enhancement to give preview to the pages prior to going to them. https://www.w3schools.com/tags/tag_iframe.asp . We apply additional hovers to make it show only when hoc-->


<?php
include_once "footer.inc";
?>
  </body>
 </html>