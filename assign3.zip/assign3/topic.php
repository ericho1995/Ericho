<!doctype html>
<html lang="en">
<head>
     <meta charset="utf-8"/> 
     <meta name="description" content="Single Page Application"/>
     <meta name="keywords" content="Topic, single page application"/>
     <meta name="author"   content="Tai Eric Ho"/>
     <title>Topic - Single Page Application</title> 
     <!-- References to external CSS files -->
     <link href= "styles/style.css" rel="stylesheet"/>
	 <link href= "styles/topic.css" rel="stylesheet"/>
	 <link href="styles/enhancement.css" rel="stylesheet"/>
	 

 <body>
<?php
include_once "topicheader.inc";
include_once "nav.inc";
?>
	 <br>
	 <hr>
	 <section>
	 <h2>What is a Single Page Application?</h2>	 
	 <p><strong>SPA</strong> is a website application / design where instead of loading new browser pages it will dynamically load and add more resources as necessary to the page, usually in response to the users actions. 
	 Applications you're very familiar with that are SPA: Facebook, Twitter, GMail, Google Maps or even Netflix.</p>
	 <img src="images/facebook.png" width="100" height="100" alt="facebook icon"> <!-- https://www.kindpng.com/imgv/bRRhom_facebook-logo-circle-email-signature-facebook-icon-small/#gal_facebook-logo-circle-email-signature-facebook-icon-small-hd-png-download_bRRhom_571745.png -->
	 <img src="images/googlemaps.png" width="100" height="100" alt="googlemaps icon"> <!-- https://pngio.com/images/png-a1505570.html -->
	 <img src="images/twitter.png" width="100" height="100" alt="twitter icon"> <!-- https://www.iconfinder.com/icons/173834/twitter_icon  -->
	    <aside>
	    <!-- https://dev.to/mquanit/single-page-application-vs-multi-page-application-p2m -->
	    <strong>Multi-page Applications </strong> is the alternative where requests will reload the entire page and display the new requested page. When it comes to MPAs think: Amazon, Ebay, Forbes
	    </aside>
	 </section>
	 
	 
	 
	 <section>
	 <h2>What are the benefits of SAP?</h2>
	 
	 <h3>Advantage of SPA </h3> <!-- Information combination of https://rubygarage.org/blog/single-page-app-vs-multi-page-app#article_title_1 by Anastasia Z and https://medium.com/@shifat.jaman/single-page-application-everything-you-need-to-know-6f00d87e5130 by Shifat Jaman -->
	 <ol>
       <li><b>Fast and responsive </b>– SPA loads the majority of the applications once and will only update required content in turn improving the website’s speed. </li>
       <li><b>Efficiency </b> – Time removed from waiting for new pages to load from the alternative Multiple Page Application </li>
       <li><b>Easier to Debug</b>– As all codes are on a single page making it easier for the developer to debugs </li>
       <li><b>User friendly</b> - Users do not have load a new page, scrolling is convenient and uninterrupted, creating a much more enjoyable experience
     </ol>
	 </section>
	 
	 <section>
	 <h2>What are the disadvantages of SPA?</h2>
	 
	 <h3>Disadvantages of SPA </h3> <!-- Information combination of https://rubygarage.org/blog/single-page-app-vs-multi-page-app#article_title_1 by Anastasia Z and https://medium.com/@shifat.jaman/single-page-application-everything-you-need-to-know-6f00d87e5130 by Shifat Jaman -->
	 <ul>
	 
        <li><b>Poor SEO optimization</b> – As single page applications are operated by Javascript downloads data upon user request therefore the URL does not change. Therefore, making it difficult to optimize website for search engines since pages cannot be searched by bots.</li>
		
        <li><b>Browser history</b> – SPA does not save the users page status therefore when the users clicks back they will not go back to the previous state of the application.</li>
		
        <li><b>Security issues</b> – SPA are more exposed to cross-site scripting (Xss) attacks. Hackers can deliver dangerous scripts to other users</li>
	 
	 </ul>
     
	 </section>
	 
	 <!-- https://www.toobler.com/frameworks-for-developing-single-page-applications/ -->
	 <section>
	 <h2> Some popular frameworks for developing SPA </h2>
	 <br>
	 <table>
	    <tr>
		  <th><a href="https://angular.io/"><img src="images/angularjs.png" alt ="Angular" id="angular"></a></th> <!--  https://worldvectorlogo.com/downloaded/angular-->
		  <th><a href="https://vuejs.org/"><img src="images/vue.png" alt ="Vue" id="vue"></a></th> <!-- https://worldvectorlogo.com/downloaded/vue -->
		  <th><a href="https://reactjs.org/"><img src="images/react.png" alt ="React" id="react" ></a></th> <!-- https://worldvectorlogo.com/downloaded/react -->
	      <th><a href="https://emberjs.com/"><img src="images/tomster.png" alt ="Emberjs" id="ember" ></a></th> <!-- https://worldvectorlogo.com/downloaded/ember-tomster -->
		  <th><a href="https://backbonejs.org/"><img src="images/backbone.png" alt ="Backbonejs" id="backbone" ></a></th> <!-- https://worldvectorlogo.com/logo/backbone-icon -->
		 </tr>
		 <tr>
		   <td>“Angularjs is one of the open-source, front-end, JavaScript-based frameworks widely used in creating single page applications on the client side” - Angularjs<!-- https://www.toobler.com/frameworks-for-developing-single-page-applications/ --></td>
		   <td>"Vuejs is a progressive framework for building user interfaces." - Vue. <!-- https://vuejs.org/v2/guide/ --> Perfectly capable of powering SPAs when used in combinations with modern tooling an supporting libraries.</td>
		   <td>“Reactjs is more of a library than a framework which is used for creating User interface (UI) Applications” - Reactjs<!-- https://www.toobler.com/frameworks-for-developing-single-page-applications/ --></td>
		   <td>“Emberjs is a highly opinionated, open-source framework which promotes greater flexibility" - Emberjs <!-- https://www.toobler.com/frameworks-for-developing-single-page-applications/ --></td>
	       <td>"Backbonejs is lightweight and flexible for structured codes" - Backbonejs <!--https://www.toobler.com/frameworks-for-developing-single-page-applications/ --> </td>
	   </tr>
     </table>
	 </section>
	 <br><br>


<?php
include_once "footer.inc";
?>
 </body>
 </html>