<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Search</title>

     <meta charset="utf-8" />
     <meta name="description" content="Lab 11 - Step 5" />
     <meta name="keywords" content="PHP, File, input, output" />
     <link href= "styles/style.css" rel="stylesheet"/>

</head>
<body>
    <h2>SEARCH</H2>
	<form method="post" action="search.php">
	<fieldset><legend>Member Search</legend>
		<p>	<label for="firstname">First Name: </label>
			<input type="text" name="firstname" id="firstname" /></p>

		<p>	<label for="lastname">Last Name: </label>
			<input type="text" name="lastname" id="lastname" /></p>
			
		<p>	<label for="studentid">Student ID: </label>
			<input type="text" name="studentid" id="studentid" /></p>
			
		<p>	<label for="score">Score: </label>
			<input type="text" name="score" size="10" id="score" /></p>
		
		<p>	<label for="attempt">Attempt: </label>
			<input type="text" name="attempt" size="5" id="attempt" /></p>
			
		<p>	<input type="submit" value="Search" /> </p>
		
		<i style = "font-size:11px">For students whom score 100% on first attempt please input 100 in score and 1 in attempt.</i><br><br>
		
		<i style = "font-size:11px">For students that failed the third attempt you may click the link below or type fail into first name and 3 in attempt</i><br><br>
        
	
	</fieldset>
	</form>

	
	
<?php
    
	 function sanitise_input($data) {
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
     }
	 
    if (isset($_POST["firstname"]))
	$firstname	= sanitise_input($_POST["firstname"]);
    
    if (isset($_POST["studentid"]))
	$studentid	= sanitise_input($_POST["studentid"]);
    
    if (isset($_POST["lastname"]))
	$lastname	= sanitise_input($_POST["lastname"]);
	
	if (isset($_POST["score"]))
	$score	= sanitise_input($_POST["score"]);
	
	if (isset($_POST["attempt"])){
	$attempt	= sanitise_input($_POST["attempt"]);

	
         require_once('settings.php');
    
	
	$conn = @mysqli_connect($host,
		$user,
		$pwd,
		$sql_db
	);
  
	// Checks if connection is successful
	if (!$conn) {
		// Displays an error message
		echo "<p class=\"wrong\">Database connection failure</p>"; // Might not show in a production script 
	} else {
		// Upon successful connection
		
	$sql_table="attempts4";
	
		// Set up the SQL command to add the data into the table
		if (($score == 100) && ($attempt == 1)){
		$query = "select firstname, lastname, studentid, score, attempt from $sql_table where score = '$score' and attempt = '$attempt'";
		}
		else if(($firstname == "fail") && ($attempt == 3)){
		$query = "select firstname, lastname, studentid, score, attempt from $sql_table where score <= 50 and attempt = '3' ";
		}
		else {
		$query = "select firstname, lastname, studentid, score, attempt from $sql_table where firstname='$firstname' or lastname='$lastname' 
		or studentid = '$studentid' or score = '$score' or attempt = '$attempt' ";
		}
		
		// execute the query and store result into the result pointer
		$result = mysqli_query($conn, $query);
		
		// checks if the execuion was successful
		if(!$result) {
			echo "<p class=\"wrong\">Something is wrong with ",	$query, "</p>";
		} else {
		if(mysqli_num_rows($result)>0) {
			// Display the retrieved records
			echo "<h2>Search Results</h2>";
			echo "<table>";
			echo "<tr>\n"
			     ."<th scope=\"col\">First Name</th>\n"
				 ."<th scope=\"col\">Last Name</th>\n"
				 ."<th scope=\"col\">Student ID</th>\n"
				 ."<th scope=\"col\">Score %</th>\n"
				 ."<th scope=\"col\">Attempts</th>\n"
				 ."</tr>\n";
			
			    
			while ($row = mysqli_fetch_assoc($result)){
				
				echo "<tr>";
				echo "<td>",$row["firstname"],"</td>";  
				echo "<td>",$row["lastname"],"</td>";
				echo "<td>",$row["studentid"],"</td>";
				echo "<td>",$row["score"],"%</td>";
				echo "<td>",$row["attempt"],"</td>";
				echo "</tr>";
			}
			echo "</table>";
			
			mysqli_free_result($result);
		}
		else {
			
			$query = "select * from attempts4;";
			$result = mysqli_query($conn, $query);
			
			echo "<h2>No match found. Here is a list of all student attempts</h2>";
			echo "<table>\n";
			echo "<tr><th>First name</th><th>Lastname</th><th>Student ID</th><th>Score %</th><th>Attempt #</th>\n";
			
			while ($row = mysqli_fetch_assoc($result)){
				echo "<tr>\n";
				echo "<td>", $row["firstname"],"</td>\n";
				echo "<td>", $row["lastname"],"</td>\n";
				echo "<td>", $row["studentid"],"</td>\n";
				echo "<td>", $row["score"],"%</td>\n";
				echo "<td>", $row["attempt"],"</td>\n";
				echo "</tr>\n";
			}
			echo "</table>";
		}
		} 
		
		mysqli_close($conn);
	} 
      
	} 
?>

	<br><form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/manage.php"><input type="submit" value= "Back to manage"/></form><br>
	
	<form method="post" action="fail.php">
	<input type="submit" value="Students with less that 50% on their third attempt" />
	</form>
</body>
</html>