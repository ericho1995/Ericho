<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Search</title>

     <meta charset="utf-8" />
     <meta name="description" content="Lab 11 - Step 5" />
     <meta name="keywords" content="PHP, File, input, output" />
     <link href= "styles/style.css" rel="stylesheet"/>

</head>
<body>
    <h2>Students with scored less that 50% on attempt 3</h2>
	
<?php
         require_once('settings.php');
    
	
	$conn = @mysqli_connect($host,
		$user,
		$pwd,
		$sql_db
	);
  
	// Checks if connection is successful
	if (!$conn) {
		// Displays an error message
		echo "<p class=\"wrong\">Database connection failure</p>"; // Might not show in a production script 
	} else {
		// Upon successful connection
		
	$sql_table="attempts4";
	
		$query = "select firstname, lastname, studentid, score, attempt from $sql_table where score <= 50 and attempt = '3' ";
			
		$result = mysqli_query($conn, $query);
		
		// checks if the execuion was successful
		if(!$result) {
			echo "<p class=\"wrong\">Something is wrong with ",	$query, "</p>";
		} else {
		if(mysqli_num_rows($result)>0) {
			
			  echo "<h2>Search Results</h2>";
			echo "<table>";
			echo "<tr>\n"
			     ."<th scope=\"col\">First Name</th>\n"
				 ."<th scope=\"col\">Last Name</th>\n"
				 ."<th scope=\"col\">Student ID</th>\n"
				 ."<th scope=\"col\">Score</th>\n"
				 ."<th scope=\"col\">Attempts</th>\n"
				 ."</tr>\n";
			
			  
			while ($row = mysqli_fetch_assoc($result)){
				
				echo "<tr>";
				echo "<td>",$row["firstname"],"</td>";  
				echo "<td>",$row["lastname"],"</td>";
				echo "<td>",$row["studentid"],"</td>";
				echo "<td>",$row["score"],"</td>";
				echo "<td>",$row["attempt"],"</td>";
				echo "</tr>";
			}
			echo "</table>";
			
			mysqli_free_result($result);

		
		}
		} 
		mysqli_close($conn);
	} 
?>
    <br>
	<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/manage.php"><input type="submit" value= "Back to manage"/></form>
	<br>
	<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/search.php"><input type="submit" value= "To search page"/></form>
</body>
</html>