
<?php
	if (isset ($_POST["studentid"]))
	       $studentid=$_POST["studentid"];
    else {
		header("location:manage.php");
		exit();
	}
	
	require_once "settings.php";	
	$conn = @mysqli_connect ($host,$user,$pwd,$sql_db);	
	if ($conn) { 
		$query = "DELETE FROM attempts4 WHERE studentid = '$studentid'";
		$result = mysqli_query ($conn, $query);
		if ($result) {								
			echo "<p>Delete operation successful.</p>";
			 header ("location: manage.php");
		} else {
			echo "<p>Delete operation unsuccessful.</p>";
		}
		mysqli_close ($conn);					
	} else {
		echo "<p>Unable to connect to the database.</p>";
	}
?>	
