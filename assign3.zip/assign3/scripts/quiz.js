/*
* Author: Tai Eric Ho
* Target: quiz.html
* Purpose: assignment 2
* Credits: Eric Ho
*/

"use strict"


function saveResult (names){//save the inputs and scores into their respective attempts.
	if(typeof(Storage)!=="undefined"){
		localStorage.setItem("firstName", names[0]);
		localStorage.setItem("surname", names[1]);
		localStorage.setItem("studID", names[2]);
		localStorage.setItem("score", names[3]);
		
		if (localStorage.getItem("attempt" + 1) == null){
		    localStorage.setItem("attempt" + 1, (names[0] + " " + names[1] + " " + names[3] + "/10"));
			}
	    else if (localStorage.getItem("attempt" + 2) == null){
		    localStorage.setItem("attempt" + 2, (names[0] + " " + names[1] + " " + names[3] + "/10"));
			}
		else if (localStorage.getItem("attempt" + 3) == null){
		    localStorage.setItem("attempt" + 3, (names[0] + " " + names[1] + " " + names[3] + "/10"));	 
		}
	}
}

function getResult(){//print the text 
	if(typeof(Storage)!=="undefined"){
		if (localStorage.getItem("firstName") !== null) {
			
			var firstName = document.getElementById("firstName");
			firstName.textContent = localStorage.getItem("firstName") + " " + localStorage.getItem("surname") ;
			
			var studID = document.getElementById("studID");
			studID.textContent = localStorage.getItem("studID"); 
			
			var score = document.getElementById("score");
			score.textContent = localStorage.getItem("score");
			
			var attempt = document.getElementById("attempt1");
			attempt1.textContent = localStorage.getItem("attempt1");
			
			if (localStorage.getItem("attempt" + 2) !== null){
			   var attempt2 = document.getElementById("attempt2");
			   attempt2.textContent = localStorage.getItem("attempt2");
			}   
			
			if (localStorage.getItem("attempt" + 3) !== null){
			   var attempt3 = document.getElementById("attempt3");
			   attempt3.textContent = localStorage.getItem("attempt3");
			}   
			
		}	
	}
}
	
//make first letter of names capital.
function change(){
   	var firstname = document.getElementById("firstName").value;
	var lastname = document.getElementById("surname").value;
	firstname = firstname.charAt(0).toUpperCase() + firstname.slice(1);
	lastname = lastname.charAt(0).toUpperCase() + lastname.slice(1);
	document.getElementById("firstName").value = firstname;
	document.getElementById("surname").value = lastname;
}		

//onsubmit this will validate the data: completion of all questions, score above 0 or else it will not allow submission.
function validate() {
	var errMsg="";
	var result=true;
	var score = 0;
	
	change();
	var firstName = document.getElementById("firstName").value;
	var surname = document.getElementById("surname").value;
	var studID = document.getElementById("studID").value;
	var q1 = document.getElementById("q1").value.trim(); //question 1
	var q2=document.getElementById("q2").getElementsByTagName("input"); //question 2
	var q3=document.getElementById("q3").getElementsByTagName("input"); //question 3
	var q4a=document.getElementById("q4debugging").value;// question 4a
	var q4b=document.getElementById("q4userfriendly").value;// question 4b
	var q4c=document.getElementById("q4efficiency").value;//question 4c
	var q5 = document.getElementById("q5").value; //question 5
     	
	if (firstName == "") {
		errMsg += "Please enter your first name.<br>";
		result = false
	}
	
	if (surname == "") {
		errMsg += "Please enter your surname name.<br>";
		result = false
	}
	
	if (studID == "") {
		errMsg += "Please enter your student ID name.<br>";
		result = false
	}
	
    //question 1
	if (q1 == "") {
		errMsg += "Please answer question 1.<br>";
		result = false
	}
	else if (q1.match(/facebook/i)) {
	    score += 2;
	}
	
	//question 2
	if (q2[0].checked){
	}		
	else if (q2[1].checked){
	}	
	else if (q2[2].checked){
	}	
	else if (q2[3].checked){
	    score += 2;
	}
	else {
	    errMsg += "Please answer question 2.<br>";
		result = false
	}//end of question 2
	
	
	//question 3
	if (q3[0].checked == true && q3[1].checked == true && q3[3].checked == true){
	    score += 2;
    }
	
	//question 3 check test.
	let x = 0;
	do {
		if(q3[x].checked == true){
			break;
		}
		else{
		x ++;
		}
	} while(x < q3.length);
	
	
	if (x == 5){
		x--;
	}
	if (q3[x].checked == false){
			 errMsg += "Please answer question 3.<br>";
		     result = false;
	}
	// end of question 3 code.	
   
   
   //question 4
    if (q4a == "Correct" && q4b == "Correct" && q4c == "Correct"){
	   score += 2;
    }
	else if (q4a == ""){
	    errMsg += "Please answer question 4a.<br>";
		result = false;
	}		
		
	if (q4b == ""){
	    errMsg += "Please answer question 4b.<br>";
		result = false;
	}	
	
	if (q4c == ""){
	    errMsg += "Please answer question 4c.<br>";
		result = false;
	}	
	
	
	//question 5
	if (q5 == 4){
		score += 2
	}//end of q5
	
	
	if (errMsg !="") 
		document.getElementById("err").innerHTML=errMsg;
	else if (score==0) {
		document.getElementById("err").innerHTML="You've score zero. Hover hint on Question 1.";
		result=false;
	}
    else {  
        var names = [firstName, surname, studID, score];	
		saveResult(names);
	}
	return result;	//will submit if true else it will pop up error messages
}

function myFunction() {//click button on result.html to redirect to quiz if 3 attempts haven't been made.
	if (localStorage.attempt3 == null){	 
		window.location.href = "quiz.html";
	}
	else{
	    document.getElementById("button").onclick=null;
        document.getElementById("button").innerHTML = "All three attempts exhausted"	
	}
}

function timer(){ //ENHANCEMENT. Timer that will count every 1 second downwards

    var count = document.getElementById("timer").textContent;
    var countdown = setInterval(function(){
    count--;
    document.getElementById("timer").textContent = count;
    if(count <= 0){
     alert("You have run out of time"); //run out of time.
	 if (localStorage.getItem("firstName") !== null){
	   var names = [localStorage.getItem("firstName"), localStorage.getItem("surname"),localStorage.getItem("studID"), 2]
	   clearInterval(countdown); //after failing print out most recent name if there's one and get 2 marks
		} 
     else {
	   var names = ["failed", "the test", 0, 0] //no names have done the test. Give them a fail and 0 marks.
	   clearInterval(countdown);
		}
		 saveResult(names);
		 window.location.href = "result.html"; // after failing with time run out it will direct to results
	}
    },1000);
}
	

function init(){
	
	if (document.getElementById("quizpage")) {  // quiz page init
	    timer();
		document.getElementById("quizform").onsubmit = validate;
	}
	
	else if (document.getElementById("resultPage")) { // result page init
		getResult();	
        document.getElementById("button").onclick=myFunction;
	}
}
window.onload = init;