<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8"/> 
   <meta name="description" content="Quiz page" />
   <meta name="keywords" content="quiz, questions, assignment"/>
   <meta name="author"   content="Tai Eric Ho" />
   <title>Quiz page</title> 
     <!-- References to external CSS files -->
     <link href= "styles/style.css" rel="stylesheet"/>
	 <link href= "styles/quiz.css" rel="stylesheet"/>
	 <link href= "styles/enhancement.css" rel="stylesheet"/>
	 <script src="scripts/quiz.js"></script>
	 <!-- images and icons used for this page were from https://icon-icons.com/icon & https://worldvectorlogo.com/ free download -->
	 
	  <!-- https://www.w3schools.com/html/html5_draganddrop.asp & https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_draggable enhancement that I reapplied here-->
	  
	
</head>
<body id="quizpage">
<?php
include_once "quizheader.inc";
include_once "nav.inc";
?>

<form id="quizform" method="post" novalidate= "novalidate" action="markquiz.php">
<hr>
<h2>You have two minutes to complete the quiz</h2>
    <fieldset>
	<legend><b>Tell me about yourself</b></legend>
		<p>
		   <label for = "firstName">First Name: </label>
		   <input  name= "firstName" id="firstName" title="Please use letters or spaces only" pattern="^[A-Za-z -]+$" />
		   
		   <label for = "surname">Surname: </label>
		   <input  name= "surname" id="surname" title="Please use letters or spaces only" pattern="^[A-Za-z -]+$" />
		   
		   <label for = "studID">Student ID: </label>
		   <input  name= "studID" id="studID" title="Your Student ID is either 7 or 10 numbers" pattern="\d{7}|\d{10}" />
		

		</p> 
    </fieldset>
	<fieldset id = "fq1"> <!-- First question text input question -->
	<p><b>Question 1.</b></p>
	<label> Name a Single Page Application (SPA) that you regularly use </label><br><br>
	<input name ="q1" id="q1" />

	<div class="hint">Hover for a hint
	<span class="hinttext">F--eb--k</span>
    </div>
	</fieldset>
	<fieldset name="q2" id="q2"> <!-- Second question Multiple choice with 1 correct answer -->
	<b>Question 2.</b>
	<p>Which of the following is not an advantage of Single Page Application?</p>
	    <label for="q2efficiency">Efficiency</label>
		<input type="radio" id="q2efficiency" name="q2" value="incorrect" >
		<label for="q2userfriendly"> User Friendly</label>
		<input type="radio" id="q2userfriendly" name="q2" value="incorrect"/>
		<label for="q2easytodebug"> Easy to Debug</label>
		<input type="radio" id="q2easytodebug" name="q2" value="incorrect"/>
		<label for="q2pooroptimization"> Poor SEO optimization</label>
		<input type="radio" id="q2pooroptimization" name="q2" value="correct"/> 
	</fieldset>
	<fieldset name="q3" id="q3"> <!-- Third question Multiple Choice with multiple answers-->
	<b>Question 3.</b>   
	Which of these are Single Page Applications?<br>
		<div class="option"><img src="images/gmail.png" alt="gmail" width="15" height="15"/><label> Gmail</label>
		<input type="checkbox" name="gmail" id="gmail"  value="correct" /></div>
		<div class="option"><img src="images/facebook.png" alt="facebook" width="15" height="15"/><label> Facebook</label>
		<input type="checkbox" name="facebook" id="facebook"  value="correct"/></div>
		<div class="option"><img src="images/ebay.png" alt="ebay" width="25" height="15"/><label> Ebay</label>
	    <input type="checkbox" name="ebay" id="ebay"  value="incorrect"/></div>
	    <div class="option"><img src="images/twitter.png" alt="twitter" width="15" height="15"/><label> Twitter</label>
		<input type="checkbox" name="twitter" id="twitter"  value="correct"/></div>
		<div class="option"><img src="images/amazon.png" alt="amazon" width="25" height="15"/><label> Amazon</label> 
		<input type="checkbox"  name="amazon" id="amazon"  value="incorrect"/></div>
    	
	</fieldset>
	<fieldset name = "q4" id="q4"> <!-- Fourth question A drop list with a single correct answer-->
	<b>Question 4.</b>
	<p>Match them to their advantages:</p>
	    <label for="q4debugging">Debugging</label> - 
	         <select name="q4debugging" id="q4debugging"> 
		     <option value="none">Please Select</option>
		     <option value="Incorrect!">Users do not have to load a new page, scrolling is convenient and uninterrupted. Creating a much more enjoyable experience</option>
		     <option value="Incorrect!">Time removed from waiting for new pages to load from the alternative Multiple Page Application</option>
		     <option value="Correct">Codes are on a single page making it easier for the developer to debugs</option>
			 </select>
			 <br><br>
		<label for="q4userfriendly">User friendly</label>
			 <select name="q4userfriendly" id="q4userfriendly"> 
		     <option value="none">Please Select</option>
		     <option value="Correct">Users do not have load a new page, scrolling is convenient and uninterrupted, creating a much more enjoyable experience</option>
		     <option value="Incorrect!">Time removed from waiting for new pages to load from the alternative Multiple Page Application</option>
		     <option value="Incorrect!">Codes are on a single page making it easier for the developer to debugs</option>
			 </select>
			 <br><br>
		<label for="q4efficiency">Efficiency</label>
			 <select name="q4efficiency" id="q4efficiency">
		     <option value="none">Please Select</option>
		     <option value="Incorrect!">Users do not have load a new page, scrolling is convenient and uninterrupted, creating a much more enjoyable experience</option>
		     <option value="Correct">Time removed from waiting for new pages to load from the alternative Multiple Page Application</option>
		     <option value="Incorrect!">Codes are on a single page making it easier for the developer to debugs</option>
		     </select>
			 
	</fieldset>
	<fieldset> <!-- Fifth question make my own-->
	<b>Question. 5</b><p></p>
	See the following images. How many are frameworks for SPA?
	<p>
	<img src="images/tomster.png" alt="tomster" width="50" height="50"/>&nbsp;&nbsp;&nbsp;
	<img src="images/python.png" alt="python" width="50" height="50"/>&nbsp;&nbsp;&nbsp;
	<img src="images/vue.png" alt="vue" width="50" height="50"/>&nbsp;&nbsp;&nbsp;
	<img src="images/react.png" alt="react" width="50" height="50"/>&nbsp;&nbsp;&nbsp;
	<img src="images/angularjs.png" alt="angular" width="50" height="50"/>
	<p><label for="q5"> Number (between 1 - 5):</label>
	<input type="range" id="q5" name="q5" min="1" max="5" />
	</p>
	</fieldset>
	
	<input type = "submit" value="Complete"/>
	<input type="reset" value="Reset"/><p></p>
	 </form>	
<?php
include_once "footer.inc"
?>

</body>
</html>