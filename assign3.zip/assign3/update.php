<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8 " />
	<title>Update PHP</title>

</head>
<body>
<?php
     function sanitise_input($data) {
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
     }
	
	if (isset($_POST["score"])){
	$score	= sanitise_input($_POST["score"]);
    }
	else {
	echo "<p>Did you forget an score?</p>";
	}
    if (isset($_POST["studentid"])){
	$studentid	= sanitise_input($_POST["studentid"]);
    }
	else {
	echo "<p>Did you forget the student ID?</p>";
	}
	if (isset($_POST["attempt"])){
	$attempt = sanitise_input($_POST["attempt"]);
    }
	else {
	echo "<p>Did you forget an attempt number?</p>";
	}
	
	
	require_once "settings.php";	// Load MySQL log in credentials
	$conn = @mysqli_connect ($host,$user,$pwd,$sql_db);	// Log in and use database
	if ($conn) { // check is database is available for use
	    if (($score != "") && ($studentid != "")){
		$query = "UPDATE `attempts4` SET `score`='$score' WHERE (studentid = $studentid AND attempt = $attempt)" ;
		}
		$result = mysqli_query ($conn, $query);
		if ($result) {								// check if query was successfully executed
			echo "<p>Update operation successful.</p>";
			header ("location: manage.php");
		} else {
			echo "<p>Update operation unsuccessful.</p>";
			echo "<p>Did you put in the correct student ID?</p>";
			header ("location: manage.php");
		}
		mysqli_close ($conn);					// Close the database connect
	} else {
		echo "<p>Unable to connect to the database.</p>";
	}
?>	
</body>
</html>