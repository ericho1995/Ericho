<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8"/> 
   <meta name="description" content="Quiz page" />
   <meta name="keywords" content="quiz, questions, assignment"/>
   <meta name="author"   content="Tai Eric Ho" />
   <title>Assignment 3</title> 
     <link href= "styles/style.css" rel="stylesheet"/>
	 <link href= "styles/quiz.css" rel="stylesheet"/>
</head>

<?php
   $page = "quizPage";
   include_once "header.inc";
   include_once "nav.inc";
?>


<?php
     //sanitise function from processbooking
     function sanitise_input($data) {
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
     }
     //sanitise data.
	 $firstname = $_POST["firstName"];
	 $firstname = sanitise_input($_POST["firstName"]);
     $surname = $_POST["surname"];
	 $surname = sanitise_input($_POST["surname"]);
     $studentid = $_POST["studID"];
	 $studentid = sanitise_input($_POST["studID"]);
     $q1 = $_POST["q1"];
	 $q1 = sanitise_input($_POST["q1"]);
	 
	 $errMsg = "";
    //firstname, lastname and surname checks.
	if ($firstname == "") {
		$errMsg .= "<p>You must enter your first name. </p>";
	}
	else if (!preg_match("/^[-a-zA-Z ]{0,20}$/",$firstname)) {
		$errMsg .= "<p>Only alpha letters and maximum of 20 letters allowed in your first name. </p>";
	}
	else if (!preg_match("/^[-a-zA-Z ]{0,20}$/",$surname)) {
		$errMsg .= "<p>Only alpha letters and maximum of 20 letters allowed in your last name. </p>";
	}
    else if (!preg_match("/^[0-9]{7}$|^[0-9]{10}$/",$studentid)){ 
		$errMsg .= "<p>Student Id be 7 or 10 digits </p>";
	}
	
	// check whether the questions have been answered
	if ($q1 == "") {
		$errMsg .= "<p>You did not answer question 1 </p>";
	}
	if (!isset ($_POST["q2"])) {
		$errMsg .= "<p>You did not answer question 2 </p>";
	}


	
	$score = 0;
	//give scoring to correct quiz answers
	//question 1
	if (isset ($_POST["q1"])) {
		$q1 = $_POST["q1"];
	}
	
	if (preg_match("/facebook/i", $q1)) {
		$score += 2;
	}
	
	//question 2
	if (isset ($_POST["q2"])){
		$q2 = $_POST["q2"];
		if ($q2 == "correct") {
		$score += 2;
	   }
	}
	
	
	//question 3 (one way)
	 //if (isset ($_POST["gmail"]) &&(isset ($_POST["facebook"])) && (isset ($_POST["twitter"])) && (!isset ($_POST["ebay"])) && (!isset ($_POST["amazon"]))){
		// echo "<p>correct for question 3</p>";
		// $score += 2;
		// echo "<p>$score</p>";
	 //}
	 
	 $q3 = "";
     if (isset ($_POST["gmail"])) $q3 = $q3."yes";
 	 if (isset ($_POST["facebook"])) $q3 = $q3."yes";
	 if (isset ($_POST["twitter"])) $q3 = $q3."yes";
	 if (isset ($_POST["ebay"])) $q3 = $q3."no";
	 if (isset ($_POST["amazon"])) $q3 = $q3."no";
	 
	 if ($q3 == "yesyesyes") {
		 $score += 2;
	 }
	
	//place if statements for question 3 to check for inputs
	if ($q3 == "") {
		$errMsg .= "<p>You did not answer question 3 </p>";
	}
	
	//question question 4 verification
	if (isset ($_POST["q4debugging"])) {
		$q4a = $_POST["q4debugging"];
		if ($q4a == "none") {
		$errMsg .= "<p>Please answer question 4a </p>";	
		}
	}
	if (isset ($_POST["q4userfriendly"])) {
		$q4b = $_POST["q4userfriendly"];
		if ($q4b == "none") {
		$errMsg .= "<p>Please answer question 4b </p>";	
		}
	}
	if (isset ($_POST["q4efficiency"])) {
		$q4c = $_POST["q4efficiency"];
		if ($q4c == "none") {
		$errMsg .= "<p>Please answer question 4c </p>";	
		}
	}

	//question 4
	if (($q4a == "Correct") && ($q4b == "Correct") && ($q4c == "Correct")) {
	$score += 2;
	}
    
	//question 5 
	$q5 = $_POST["q5"];
	if ($q5 == 4) {
	$score += 2;
	}
	
	if ($score ==0){
		$errMsg .= "<p>Your score is 0. Please go back, this attempt did not count.</p>";	
	}
	
	$score = (($score / 10)*100);

	
	//error message if inputs are incorrect or if they didn't answer the questions
 	if ($errMsg != ""){
		echo "$errMsg";
		echo '<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/quiz.php"><input type="submit" value= "Try again"/></form>';
	}
	else {
	 
   require_once("settings.php");
   $conn = @mysqli_connect($host, $user, $pwd, $sql_db);
	if (!$conn) {
		echo "<p>Database connection failure</p>";
	} 
	else {
	$query = "create table if not exists attempts4(
              ID INT AUTO_INCREMENT PRIMARY KEY,
			  date VARCHAR(20),
              firstname VARCHAR(20),
              lastname VARCHAR(20),
              studentid VARCHAR(10),
              score int,
              attempt int);"; 	
			  
	$firstname=htmlspecialchars($firstname);
	$surname=htmlspecialchars($surname);
	$studentid=htmlspecialchars($studentid);
	$date = date('Y-m-d H:i:s');
	 
    //$sql_table="attempts4";
    //$query = "insert into $sql_table(firstname, lastname, studentid, score) values ('$firstname', '$surname', '$studentid', '$score')";
    // exectute the query we- sshould really check to see if the database exists first
    $result = mysqli_query($conn, $query);
    if (!$result) {
 	   echo "<p class= \"wrong\">Something is wrong with ", $query, "</p>";
    }
	else {
		$query0= "select MAX(attempt) as attempt from attempts4 where studentid='$studentid'";
		$result0 = mysqli_query($conn, $query0);
		if (!$result0){
			echo "<p>Something  is wrong with $query0<p>";
		}
		else {
			$row = mysqli_fetch_assoc($result0);
			if (!$row)
			$attempt = 0;
			else
			$attempt = $row["attempt"];
			mysqli_free_result ($result0);
		}
		$attempt += 1;
		if ($attempt < 4){
		$insert_query = "INSERT into attempts4 (date, firstname, lastname, studentid, score, attempt) 
		                 VALUES ('$date', '$firstname', '$surname', '$studentid', '$score','$attempt');";
		
		$insert_result = mysqli_query($conn, $insert_query);
		$remaining_attempt = 3 - $attempt ;				 
	    if ($insert_result) {
			echo "<h2>Results</h2>";
			echo "<p>Date & Time: $date</p>";
		    echo "<p>Name: $firstname $surname</p><p>Student ID: $studentid</p><p>Score: $score%</p><p>Attempt #: $attempt</p>";
			echo "<p>You have $remaining_attempt attempt(s) left<p>";
			if (!$remaining_attempt == 0) {
			echo '<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/quiz.php"><input type="submit" value= "Try again"/></form>';
			}
			else {
			echo "<p><b>Supervisor use only</b></p>";
			echo '<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/manage.php"><input type="submit" value= "Manage"/></form>';
			}
		}
		else {
			echo "<p>Insert unsuccessful</p>";
		}
		}
		else {
		echo "<p>You have already completed your 3 attempts</p>";
		echo "<p><b>Supervisor use only</b></p>";
		echo '<form action = "https://mercury.swin.edu.au/cos10011/s103279560/assign3/manage.php"><input type="submit" value= "Manage"/></form>';
		}
    }
	mysqli_close($conn);
	}
	}
	
?>


<?php
include_once "footer.inc";
?>
