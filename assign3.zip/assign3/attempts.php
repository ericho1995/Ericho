<?php

   $firstname = trim($_POST["firstName"]);
   $surname = trim($_POST["surname"]);
   $studentid = trim($_POST["studID"]);
   
   require_once("settings.php");
   $conn = @mysqli_connect($host, $user, $pwd, $sql_db);
	if (!$conn) {
		echo "<p>Database connection failure</p>";
	} 
	else {
	$firstname=htmlspecialchars($firstname);
	$surname=htmlspecialchars($surname);
	$studentid=htmlspecialchars($studentid);
	 
    $sql_table="attempts";
    $query = "insert into $sql_table(firstname, lastname, studentid) values ('$firstname', '$surname', '$studentid')";
    
    $result = mysqli_query($conn, $query);
    if (!$result) {
 	   echo "<p class= \"wrong\">Something is wrong with ", $query, "</p>";
    }
	else {
		echo "<p class \"ok\">Successfully added New student record</p>";
    }
	mysqli_close($conn);
	}
	
?>
	