<!DOCTYPE html>
<html lang="en">
<head>
<title>Quiz Table</title>

     <meta charset="utf-8"/>
     <meta name="description" content="Lab 10" />
     <meta name="keywords" content="PHP, File, input, output"/>
     <link href= "styles/style.css" rel="stylesheet"/>
	 <link href= "styles/quiz.css" rel="stylesheet"/>

</head>
<body>
<?php
   include_once "header2.inc";
   include_once "nav.inc";
?>
<?php
     function sanitise_input($data) {
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
     }
	 
    require_once("settings.php");
	$conn = @mysqli_connect($host, $user, $pwd, $sql_db);
	
	if (!$conn) {
		echo "<p>Database connection failure</p>";
	} else {
		
	    // set up the SQL command to query or add data into the tabke
	    $query = "select * from attempts4;";
		
		//execute the query and store result into the result pointer
		$result = mysqli_query($conn, $query);
		
		//checks if the execution was successful
		if (!$result) {
			echo "<p>Something is wrong with ", $query, "</p>";
		}
		else {
			echo "<h2>List of all student attempts</h2>";
			echo "<table>\n";
			echo "<tr><th>First name</th><th>Lastname</th><th>Student ID</th><th>Score %</th><th>Attempt #</th>\n";
			
			while ($row = mysqli_fetch_assoc($result)){
				echo "<tr>\n";
				echo "<td>", $row["firstname"],"</td>\n";
				echo "<td>", $row["lastname"],"</td>\n";
				echo "<td>", $row["studentid"],"</td>\n";
				echo "<td>", $row["score"],"%</td>\n";
				echo "<td>", $row["attempt"],"</td>\n";
				echo "</tr>\n";
		}
        echo "</table>\n";
        
        mysqli_free_result($result);		
			
		mysqli_close($conn);
	}
	
	}
		
	
?>


    <br><br>
	<form method="post" action="search.php">
	<fieldset><legend>Member Search</legend>
	<p><input type="submit" value="Search page" /></p>
	</fieldset>
	</form><br>
	
	<form method="post" action="fail.php">
	<fieldset><legend>Student that scored less than 50% on third attempt</legend>
	<p><input type="submit" value="Click here for result" /></p>
	</fieldset>
	</form>
	

	<form action="delete.php" method="post">
    <fieldset><legend>Delete based on student number</legend>
	<p><label>Student ID: <input type ="text" name= "studentid" /></label></p>
	<input type = "submit" value = "Delete" />
	</fieldset>
	</form>
	
	<form action = "update.php" method = "post">
	<fieldset><legend>Change the score for a quiz attempt</legend>
	<p><label>Student ID: <input type="text" name="studentid" /></label></p>
	<p><label>Attempt #: <input type="text" name="attempt" /></label></p>
	<p><label>New Score: <input type="text" name="score" /></label></p>
	<input type = "submit" value = "Update" />
	</fieldset>
	<br><br><br>
    </form>

</body>
</html>